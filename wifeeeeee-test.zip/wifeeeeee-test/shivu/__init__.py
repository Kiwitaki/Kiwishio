import os
import telegram.ext as tg
from pyrogram import Client
import logging  
from telegram.ext import Application
from motor.motor_asyncio import AsyncIOMotorClient
logging.basicConfig(
    format="%(asctime)s - %(levelname)s - %(name)s - %(message)s",
    handlers=[logging.FileHandler("log.txt"), logging.StreamHandler()],
    level=logging.INFO,
)

logging.getLogger("apscheduler").setLevel(logging.ERROR)
logging.getLogger('httpx').setLevel(logging.WARNING)
logging.getLogger("pyrate_limiter").setLevel(logging.ERROR)
LOGGER = logging.getLogger(__name__)

OWNER_ID = "6384296585"
sudo_users = ['5982968099', '8015760732', '2081927790', '5670095072', '1643054031',  '6988555661', '7271891429', '6945867237', '6274402437', '1577166444', '6494814225']
GROUP_ID = -1002141403968
TOKEN = "6883098627:AAH1rBrkGylEk8hv36MtVPJhtWJi6kcQvic"
mongo_url = "mongodb+srv://Takievil:takievil098@takievil.uallkel.mongodb.net/waifu_bot?retryWrites=true&w=majority"
PHOTO_URL = [
    "https://telegra.ph/file/d834cb77c4bfb68850f85.jpg",
    "https://telegra.ph/file/59debd172411c818e643a.jpg",
    "https://telegra.ph/file/e5f5c83657de2786a2720.jpg"
]

SUPPORT_CHAT = "Catch_Your_WH_Group"
CHARA_CHANNEL_ID = -1002292704257
API_HASH = "e9a3897c961f8dce2a0a88ab8d3dd843"
API_ID = 29593257
UPDATE_CHAT = "CATCH_YOUR_WH_UPDATES"
BOT_USERNAME = os.getenv("BOT_USERNAME")
DEV_LIST = [1643054031, 6312693124, 8015760732, 6384296585,6988555661]

application = Application.builder().token(TOKEN).build()
shivuu = Client(
    "lmao",
    api_id=API_ID,
    api_hash=API_HASH,
    bot_token=TOKEN,
    
    
)
client = AsyncIOMotorClient(mongo_url)
db = client['waifus']
collection = db['all_characters']
event_collection = db['event_collection']
user_totals_collection = db['user_totals']
user_collection = db["user_collection"]
group_user_totals_collection = db['group_user_totals']
top_global_groups_collection = db['top_global_groups']
settings_collection = db["settings"]
banned_users = db["ban_user"]
