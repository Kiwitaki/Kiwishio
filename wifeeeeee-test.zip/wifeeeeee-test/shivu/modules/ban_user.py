from telegram import Update
from telegram.ext import CommandHandler, CallbackQueryHandler, CallbackContext
from telegram.ext import CommandHandler, MessageHandler, filters
from shivu import application, DEV_LIST, banned_users

from typing import Optional, Tuple

async def is_user_banned(user_id: int) -> Tuple[bool, Optional[str]]:
    try:
        user = await banned_users.find_one({'user_id': user_id})
        if user:
            return True, user.get('reason', 'No reason provided.')
        return False, None
    except Exception as e:
        print(f"Error checking banned user: {e}")
        raise


async def botban_command(update: Update, context: CallbackContext) -> None:
    user_id = update.effective_user.id
    
    if update.message.reply_to_message:
        target_user = update.message.reply_to_message.from_user
        reason = ' '.join(context.args) if context.args else "No reason provided."
    elif len(context.args) >= 1:
        try:
            target_user_id = int(context.args[0])
            target_user = await context.bot.get_chat(target_user_id)
            reason = ' '.join(context.args[1:]) if len(context.args) > 1 else "No reason provided."
        except ValueError:
            await update.message.reply_text("No User Found")
            return
    else:
        await update.message.reply_text("Usage: /cban <user_id> [reason]")
        return

    
    is_banned, _ = await is_user_banned(target_user.id)
    if is_banned:
        await update.message.reply_text(f"User {target_user.full_name} is already banned.")
        return

    try:
        banned_user = {
            'user_id': target_user.id,
            'username': target_user.full_name,
            'reason': reason
        }
        await banned_users.insert_one(banned_user)
        await update.message.reply_text(f"User {target_user.full_name} has been banned. Reason: {reason}")
    except Exception as e:
        await update.message.reply_text(f"An error occurred: {e}")


async def botunban_command(update: Update, context: CallbackContext) -> None:
    if update.message.reply_to_message:
        target_user_id = update.message.reply_to_message.from_user.id
    elif len(context.args) == 1:
        try:
            target_user_id = int(context.args[0])
        except ValueError:
            await update.message.reply_text("Invalid user ID provided.")
            return
    else:
        await update.message.reply_text("Usage: /cunban <user_id>")
        return

    
    is_banned, _ = await is_user_banned(target_user_id)
    if not is_banned:
        await update.message.reply_text("User is not banned.")
        return

    try:
        result = await banned_users.delete_one({'user_id': target_user_id})
        if result.deleted_count > 0:
            await update.message.reply_text(f"User with ID {target_user_id} has been unbanned.")
        else:
            await update.message.reply_text("User is not banned.")
    except Exception as e:
        await update.message.reply_text(f"An error occurred: {e}")


application.add_handler(CommandHandler("cban", botban_command, filters.User(DEV_LIST), block=False))
application.add_handler(CommandHandler("cunban", botunban_command, filters.User(DEV_LIST), block=False))
