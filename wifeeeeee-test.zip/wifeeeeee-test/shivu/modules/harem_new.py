from telegram import (
    Update, InlineKeyboardButton, InlineKeyboardMarkup, InlineQueryResultPhoto,
    InputTextMessageContent, InputMediaPhoto, InlineQueryResultArticle
)
from telegram.ext import (
    Updater, CommandHandler, CallbackContext, MessageHandler, filters,
    InlineQueryHandler, CallbackQueryHandler, ChosenInlineResultHandler
)
from itertools import groupby
import urllib.request
import re
import math
import html
import random
from collections import Counter
from shivu import collection, user_collection, application, SUPPORT_CHAT, UPDATE_CHAT
from shivu.modules.chumma import uban
from bson import ObjectId
import asyncio


@uban
async def harem(update: Update, context: CallbackContext, page=0) -> None:
    user_id = update.effective_user.id

    user = await user_collection.find_one({'id': user_id})
    if not user:
        message = 'ʏᴏᴜ ʜᴀᴠᴇ ɴᴏᴛ ɢᴜᴇssᴇᴅ ᴀɴʏ ᴄʜᴀʀᴀᴄᴛᴇʀs ʏᴇᴛ.'
        if update.message:
            await update.message.reply_text(message)
        else:
            await update.callback_query.edit_message_text(message)
        return

    selected_rarity = user.get('selected_rarity')
    selected_style = user.get('h_style')
    selected_char = user.get('fav_character')
    
    characters = sorted(user['characters'], key=lambda x: (x['anime'], x['id']))
    rarities = ["⚪️ Common", "🟣 Rare" , "🟡 Legendary", "🟢 Medium", "💮 Exclusive", "🔮 Mythical" , "🫧 Special", "🌤 Summer", "🐦‍🔥 Marvelous", "🪼 Exotic", "🍬 Galactic", "🪔 Diwali edition", "🌟 Galaxies", "🧣 Winters", "🛷 X-Mas"]
    
    if selected_rarity and selected_rarity in rarities:
        characters = [character for character in characters if character['rarity'][0] == selected_rarity[0]]

    elif selected_char and selected_char != 'None':
        characters = [character for character in characters if character['name'].split()[0] == selected_char.split()[0]]
        
    elif selected_rarity and selected_rarity == 'Default':
        characters = sorted(user['characters'], key=lambda x: (x['anime'], x['id']))
   
    
        
    character_counts = {k: len(list(v)) for k, v in groupby(characters, key=lambda x: x['id'])}

    unique_characters = list({character['id']: character for character in characters}.values())
    if selected_style == 4:
        total_pages = math.ceil(len(unique_characters) / 6)
    else:
        total_pages = math.ceil(len(unique_characters) / 10)
        
    if page < 0 or page >= total_pages:
        page = 0

    harem_message = f"<b>{update.effective_user.first_name}'s ʜᴀʀᴇᴍ - ᴘᴀɢᴇ {page+1}/{total_pages}</b>\n"
    current_characters = unique_characters[page*10:(page+1)*10]
    current_grouped_characters = {k: list(v) for k, v in groupby(current_characters, key=lambda x: x['anime'])}
    for anime, characters in current_grouped_characters.items():
        unique_ids = {character['id'] for character in characters}
        owned_count = len(unique_ids)
        total_count = await collection.count_documents({"anime": anime})
        if selected_style:
            if selected_style == 1:
                harem_message += f'\n<b>➤ {anime} ﴾{owned_count}/{total_count}﴿</b>\n'
            elif selected_style == 2:
                harem_message += f'\n<b>⧉ {anime} ⦋{owned_count}/{total_count}⦌</b>\n'
            elif selected_rarity == "c_only":
                pass
            elif selected_rarity == "anime_only":
                harem_message += f'\n<b>⎋ {anime}</b>\n'
                harem_message += f'<b>⊰ ᴛᴏᴛᴀʟ [{total_count}]</b>\n'
                harem_message += f'<b> ⤷ ɢᴜᴇssᴇᴅ 〔{owned_count}〕</b>\n'
                harem_message += f'<b> ⤷ ʀᴇᴍᴀɪɴɪɴɢ 〔{max(total_count - owned_count, 0)}〕</b>\n'                
            elif selected_style == 3:                                
                harem_message += f'\n<b>⎋ {anime} 「{owned_count}/{total_count}」</b>\n'
            elif selected_style == 4:                                
                harem_message += f'\n<b>🈴 {anime} 「{owned_count}/{total_count}」</b>\n'
            elif selected_style == 5:                                
                harem_message += f'\n<b>⌬ {anime} 〔{owned_count}/{total_count}〕</b>\n'
        else:
            harem_message += f'\n<b>⎋ {anime} 「{owned_count}/{total_count}」</b>\n'
       
        for character in characters:
            count = character_counts[character['id']]
            if selected_style:
                if selected_rarity == "anime_only":
                    pass
                elif selected_style == 1:
                    harem_message += f'<b>⤷〔{character["rarity"][0]}〕 {character["id"]} {character["name"]} ×{count}</b>\n'
                elif selected_style == 2:
                    harem_message += f'<b>⤷〔{character["rarity"][0]}〕 {character["id"]} {character["name"]} ×{count}</b>\n'
                elif selected_rarity == "c_only":
                    harem_message += f'\n<b>☘️ Name: {character["name"]} (×{count})\n{character["rarity"][0]} Rarity: {character["rarity"][2:]} {character["id"]}\n⚜️ Anime: {character["anime"]} ({owned_count}/{total_count})</b>\n'
                elif selected_style == 3:                                
                    harem_message += f'<b>⊰ 〔{character["rarity"][0]}〕 {character["id"]} {character["name"]} ×{count}</b>\n'                
                elif selected_style == 4:                                
                    harem_message += f'<b>ID: {character["id"]} 〔{character["rarity"][0]}〕 {character["name"]} ×{count}</b>\n' 
                elif selected_style == 5:                                
                    harem_message += f'<b>◈ ⌠{character["rarity"][0]}⌡ {character["id"]} {character["name"]} ×{count}</b>\n'
            else:
                if selected_rarity == "anime_only":
                    pass
                harem_message += f'<b>⊰ 〔{character["rarity"][0]}〕 {character["id"]} {character["name"]} ×{count}</b>\n'
        if selected_style == 4 and selected_rarity not in ["anime_only", "c_only"]:
            harem_message += '----------------------\n'

                            

    total_count = len(user['characters'])
    keyboard = [
        [InlineKeyboardButton(f"sᴇᴇ ᴄᴏʟʟᴇᴄᴛɪᴏɴ ({total_count})", switch_inline_query_current_chat=f"collection.{user_id}")],
        [InlineKeyboardButton(f"{page+1}/{total_pages}", callback_data="ignore")]
    ]
    if total_pages > 1:
        nav_buttons = [
            InlineKeyboardButton("⬅️1x", callback_data=f"harem:{page-1}:{user_id}") if page > 0 else None,
            InlineKeyboardButton("1x➡️", callback_data=f"harem:{page+1}:{user_id}") if page < total_pages - 1 else None
        ]
        if page >= 6:
            nav_buttons.insert(0, InlineKeyboardButton("⏪x6", callback_data=f"harem:{page-6}:{user_id}"))
        if page + 6 < total_pages:
            nav_buttons.append(InlineKeyboardButton("6x⏩", callback_data=f"harem:{page+6}:{user_id}"))
        keyboard.append(list(filter(None, nav_buttons)))
    reply_markup = InlineKeyboardMarkup(keyboard)

    if 'favorites' in user and user['favorites']:
        fav_character_id = user['favorites'][0]
        fav_character = next((c for c in user['characters'] if c['id'] == fav_character_id), None)
        if fav_character and 'img_url' in fav_character:
            if update.message:
                await update.message.reply_photo(photo=fav_character['img_url'], parse_mode='HTML', caption=harem_message, reply_markup=reply_markup)
            else:
                if update.callback_query.message.caption != harem_message:
                    await update.callback_query.edit_message_caption(caption=harem_message, reply_markup=reply_markup, parse_mode='HTML')
        else:
            if update.message:
                await update.message.reply_text(harem_message, parse_mode='HTML', reply_markup=reply_markup)
            else:
                if update.callback_query.message.text != harem_message:
                    await update.callback_query.edit_message_text(harem_message, parse_mode='HTML', reply_markup=reply_markup)
    else:
        if user['characters']:
            random_character = random.choice(user['characters'])
            if 'img_url' in random_character:
                if update.message:
                    await update.message.reply_photo(photo=random_character['img_url'], parse_mode='HTML', caption=harem_message, reply_markup=reply_markup)
                else:
                    if update.callback_query.message.caption != harem_message:
                        await update.callback_query.edit_message_caption(caption=harem_message, reply_markup=reply_markup, parse_mode='HTML')
            else:
                if update.message:
                    await update.message.reply_text(harem_message, parse_mode='HTML', reply_markup=reply_markup)
                else:
                    if update.callback_query.message.text != harem_message:
                        await update.callback_query.edit_message_text(harem_message, parse_mode='HTML', reply_markup=reply_markup)
        else:
            if update.message:
                await update.message.reply_text("ʏᴏᴜʀ ʟɪsᴛ ɪs ᴇᴍᴘᴛʏ :)")
            

async def harem_callback(update: Update, context: CallbackContext) -> None:
    query = update.callback_query
    data = query.data
    _, page, user_id = data.split(':')
    page = int(page)
    user_id = int(user_id)

    if query.from_user.id != user_id:
        await query.answer("ᴅᴏɴ'ᴛ sᴛᴀʟᴋ ᴏᴛʜᴇʀ ᴜsᴇʀ's ʜᴀʀᴇᴍ..  OK", show_alert=True)
        return

    await harem(update, context, page)

rarities = ["⚪️ Common", "🟣 Rare" , "🟡 Legendary", "🟢 Medium", "💮 Exclusive", "🔮 Mythical" , "🫧 Special", "🌤 Summer", "🐦‍🔥 Marvelous", "🪼 Exotic", "🍬 Galactic", "🪔 Diwali edition", "🌟 Galaxies", "🧣 Winters", "🛷 X-Mas"]

async def add_rarity(update: Update, context: CallbackContext) -> None:
    global user_idh
    user_idh = update.effective_user.id
    user_id = update.effective_user.id
    user = await user_collection.find_one({'id': user_id})
    user_name = update.effective_user.first_name

    if not user:
        await update.message.reply_text("You haven't caught any characters yet.")
        return

    current_rarity = user.get('selected_rarity')

    keyboard = [
        [
            InlineKeyboardButton(f"ᴅᴇꜰᴀᴜʟᴛ {'✅️' if current_rarity == 'Default' else ''}", callback_data="add_rarity:Default"),
            InlineKeyboardButton(f"ʀᴀʀɪᴛʏ", callback_data="add_rarity:Rarity")
        ],
        [
            InlineKeyboardButton(f"ᴄʜᴀʀᴀᴄᴛᴇʀs {'✅️' if current_rarity == 'c_only' else ''}", callback_data="add_rarity:c_only"),
            InlineKeyboardButton(f"ᴀɴɪᴍᴇ {'✅️' if current_rarity == 'anime_only' else ''}", callback_data="add_rarity:anime")
        ],
        [InlineKeyboardButton("ᴄʟᴏꜱᴇ", callback_data="add_rarity:Close")]
    ]

    reply_markup = InlineKeyboardMarkup(keyboard)

    image_url = "https://telegra.ph/file/202774af0d3e0544029ba.png"
    caption = f"{user_name}, ᴘʟᴇᴀꜱᴇ ᴄʜᴏᴏꜱᴇ ʀᴀʀɪᴛʏ ᴛʜᴀᴛ ʏᴏᴜ ᴡᴀɴᴛ ᴛᴏ ꜱᴇᴛ ᴀꜱ ʜᴀʀᴇᴍ ᴍᴏᴅᴇ"

    await update.message.reply_photo(photo=image_url, caption=caption, reply_markup=reply_markup)


async def add_rarity_callback(update: Update, context: CallbackContext) -> None:
    query = update.callback_query
    data = query.data
    user_id = query.from_user.id

    if query.from_user.id != user_idh:
        await query.answer("its Not Your Harem", show_alert=True)
        return

    if data == "add_rarity:Close":
        await query.message.delete()
        return

    rarity_map = {
        "add_rarity:Default": "Default",
        "add_rarity:c_only": "c_only",
        "add_rarity:anime": "anime_only"
    }

    if data in rarity_map:
        selected_rarity = rarity_map[data]
        await user_collection.update_one({'id': user_id}, {'$set': {'selected_rarity': selected_rarity}})
        await query.message.edit_caption(caption=f"ʏᴏᴜ ꜱᴜᴄᴄᴇꜱꜱꜰᴜʟʟʏ ꜱᴇᴛ ʏᴏᴜʀ ʜᴀʀᴇᴍ ᴍᴏᴅᴇ ᴀꜱ {selected_rarity.lower()}")
    elif data == "add_rarity:Rarity":
        user = await user_collection.find_one({'id': user_id})
        current_rarity = user.get('selected_rarity')

        keyboard = []
        for i in range(0, len(rarities), 2):
            row = [InlineKeyboardButton(f"{rarities[i].title()} {'✅️' if rarities[i] == current_rarity else ''}",
                                        callback_data=f"add_rarity:{rarities[i]}")]
            if i + 1 < len(rarities):
                row.append(InlineKeyboardButton(f"{rarities[i + 1].title()} {'✅️' if rarities[i + 1] == current_rarity else ''}",
                                                callback_data=f"add_rarity:{rarities[i + 1]}"))
            keyboard.append(row)

        keyboard.append([InlineKeyboardButton("ᴄʟᴏꜱᴇ", callback_data="add_rarity:Close")])
        reply_markup = InlineKeyboardMarkup(keyboard)

        await query.message.edit_reply_markup(reply_markup=reply_markup)
    else:
        rarity = data.split(":")[1]
        await user_collection.update_one({'id': user_id}, {'$set': {'selected_rarity': rarity}})
        await query.message.edit_caption(caption=f"ʏᴏᴜ ꜱᴜᴄᴄᴇꜱꜱꜰᴜʟʟʏ ꜱᴇᴛ ʏᴏᴜʀ ʜᴀʀᴇᴍ ᴍᴏᴅᴇ ʀᴀʀɪᴛʏ ᴀꜱ {rarity}")
        
COMMANDS = [
    """➤ Honkai Star Rail [🎮] ﴾1/86﴿
⤷〔🟡〕 3547 Stelle ×1""",
    
    """⧉ Honkai Star Rail [🎮] ⦋1/86⦌
⤷〔🟡〕 3547 Stelle ×1""",
    
    """⎋ Chainsaw Man 「3/63」
⊰ 〔🟣〕 2148 Darkness Devil ×1""",

    """🈴 Zenless Zone Zero [🎮] 「1/19」
ID: 4647 〔🟣〕 Billy & Anby & Nicole ×1
------------------------""",
    
    """⌬ Bleach 〔2/78〕
◈⌠💮⌡ 2895 Byakuya Kuchiki ×1"""
]

async def harem_style(update: Update, context: CallbackContext) -> None:
    await send_style_message(update, 0)

async def send_style_message(update: Update, current_style: int) -> None:
    style_text = f"<b>ʏᴏᴜʀ sᴇʟᴇᴄᴛᴇᴅ sᴛʏʟᴇ ɴᴜᴍʙᴇʀ: {current_style + 1}</b>\n\n"
    style_text += f"<b>{COMMANDS[current_style]}</b>"

    keyboard = [
        [InlineKeyboardButton("sᴇᴛ", callback_data=f'set_{current_style + 1}')],  # 'Set' button on a separate row
    ]

    if current_style > 0 and current_style < len(COMMANDS) - 1:
        
        keyboard.append([
            InlineKeyboardButton("⬅️ ᴘʀᴇᴠɪᴏᴜs", callback_data=f'prev_{current_style}'),
            InlineKeyboardButton("ɴᴇxᴛ ➡️", callback_data=f'next_{current_style}')
        ])
    elif current_style == 0:
        
        keyboard.append([
            InlineKeyboardButton("ɴᴇxᴛ ➡️", callback_data=f'next_{current_style}')
        ])
    elif current_style == len(COMMANDS) - 1:
        
        keyboard.append([
            InlineKeyboardButton("⬅️ ᴘʀᴇᴠɪᴏᴜs", callback_data=f'prev_{current_style}')
        ])

    reply_markup = InlineKeyboardMarkup(keyboard)

    if update.message:
        await update.message.reply_text(
            style_text, 
            parse_mode='HTML', 
            reply_markup=reply_markup
        )
    elif update.callback_query:
        await handle_callback_query(update, style_text, reply_markup)


async def handle_callback_query(update: Update, style_text: str, reply_markup: InlineKeyboardMarkup) -> None:
    await update.callback_query.edit_message_text(
        style_text,
        parse_mode='HTML',
        reply_markup=reply_markup
    )

async def handle_harem_action(update: Update, context: CallbackContext) -> None:
    query_data = update.callback_query.data
    current_style = int(query_data.split('_')[-1])

    if query_data.startswith('prev'):
        new_style = current_style - 1
        await send_style_message(update, new_style)
    elif query_data.startswith('next'):
        new_style = current_style + 1
        await send_style_message(update, new_style)
    elif query_data.startswith('set_'):
        selected_style = int(query_data.split('_')[1])
        user_id = update.effective_user.id
        await user_collection.update_one({'id': user_id}, {'$set': {'h_style': selected_style}})
        await update.callback_query.edit_message_text(f"<b>sᴜᴄᴄᴇssғᴜʟʟʏ sᴇᴛ ʜᴀʀᴇᴍ sᴛʏʟᴇ ᴀs {selected_style}</b>", parse_mode='HTML')

async def fav_char(update: Update, context: CallbackContext, page=0) -> None:
    user_id = update.effective_user.id
    user = await user_collection.find_one({'id': user_id})
    
    if not user:
        await update.message.reply_text('ʏᴏᴜ ʜᴀᴠᴇ ɴᴏᴛ ɢᴜᴇssᴇᴅ ᴀɴʏ ᴄʜᴀʀᴀᴄᴛᴇʀs ʏᴇᴛ.')
        return
    
    try:
        character_id = context.args[0]
    except IndexError:
        await update.message.reply_text('ᴜsᴀɢᴇ:\nᴛᴏ sᴇᴛ ғᴀᴠᴏᴜʀɪᴛᴇ ᴄʜᴀʀᴀᴄᴛᴇʀ: /whfav ᴄʜᴀʀ_ɪᴅ\nᴛᴏ ʀᴇsᴇᴛ ʜᴀʀᴇᴍ: /whfav None')
        return
    
    if character_id == 'None':
        await user_collection.update_one({'id': user_id}, {'$set': {'fav_character': 'None'}})
        await update.message.reply_text('ʏᴏᴜʀ ʜᴀʀᴇᴍ ᴍᴏᴅᴇ ᴄʜᴀʀᴀᴄᴛᴇʀ ʜᴀs ʙᴇᴇɴ ʀᴇsᴇᴛ.')
        return

    character = next((c for c in user['characters'] if c['id'] == character_id), None)
   
    if not character:
        await update.message.reply_text('ᴛʜɪs ᴄʜᴀʀᴀᴄᴛᴇʀ ɪs ɴᴏᴛ ɪɴ ʏᴏᴜʀ ᴄᴏʟʟᴇᴄᴛɪᴏɴ.')
        return

    char_name = character.get('name')
    await user_collection.update_one({'id': user_id}, {'$set': {'fav_character': char_name}})
    
    await update.message.reply_text(f"ʏᴏᴜ ꜱᴜᴄᴄᴇꜱꜱꜰᴜʟʟʏ ꜱᴇᴛ ʏᴏᴜʀ ʜᴀʀᴇᴍ ᴍᴏᴅᴇ ᴄʜᴀʀᴀᴄᴛᴇʀ: {char_name}")
        
                    
application.add_handler(CommandHandler("whmode", add_rarity, block=False))
add_rarity_handler = CallbackQueryHandler(add_rarity_callback, pattern='^add_rarity', block=False)
application.add_handler(add_rarity_handler)
application.add_handler(CallbackQueryHandler(handle_harem_action, pattern=r'(prev_\d+|next_\d+|set_\d+)', block=False))

application.add_handler(CommandHandler("whstyle", harem_style, block=False))

application.add_handler(CommandHandler("harem", harem, block=False))

application.add_handler(CommandHandler("whfav", fav_char, block=False))

harem_handler = CallbackQueryHandler(harem_callback, pattern='^harem', block=False)
application.add_handler(harem_handler)        
