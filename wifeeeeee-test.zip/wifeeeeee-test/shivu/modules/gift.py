import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import CommandHandler, CallbackQueryHandler, CallbackContext
from shivu import user_collection, application
import time
import asyncio
import sqlite3
import json
from bson import ObjectId
from cachetools import TTLCache
from shivu.modules.chumma import uban

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)
logger = logging.getLogger(__name__)

conn = sqlite3.connect('gifts.db')
cursor = conn.cursor()

cursor.execute('''
CREATE TABLE IF NOT EXISTS pending_gifts (
    sender_id INTEGER,
    receiver_id INTEGER,
    character TEXT,
    receiver_username TEXT,
    receiver_first_name TEXT,
    PRIMARY KEY (sender_id, receiver_id, character)
)
''')

cursor.execute('''
CREATE TABLE IF NOT EXISTS last_click_time (
    user_id INTEGER PRIMARY KEY,
    timestamp REAL
)
''')
conn.commit()

gift_lock = asyncio.Lock()

click_cache = TTLCache(maxsize=100, ttl=10)

def serialize_character(character):
    character['_id'] = str(character['_id'])
    return json.dumps(character)

def deserialize_character(character_str):
    character = json.loads(character_str)
    character['_id'] = ObjectId(character['_id'])
    return character

@uban
async def gift(update: Update, context: CallbackContext) -> None:
    message = update.effective_message
    sender_id = update.effective_user.id

    if not message.reply_to_message or len(context.args) != 1:
        await message.reply_text("Invalid usage. Reply to a user's message and provide a character ID.")
        return

    receiver_id = message.reply_to_message.from_user.id
    receiver_username = message.reply_to_message.from_user.username
    receiver_first_name = message.reply_to_message.from_user.first_name

    if sender_id == receiver_id:
        await message.reply_text("You can't gift a character to yourself!")
        return

    if update.message.reply_to_message.from_user.is_bot:
        await message.reply_text("Brilliant Bro, At least See Who I Am🤡")
        return

    character_id = context.args[0]
    sender = await user_collection.find_one({'id': sender_id})

    characters = sender.get('characters', [])
    character = next((char for char in characters if char.get('id') == character_id), None)

    if not character:
        await message.reply_text("You don't have this character in your collection!")
        return

    async with gift_lock:
        cursor.execute('''
        INSERT OR REPLACE INTO pending_gifts (sender_id, receiver_id, character, receiver_username, receiver_first_name)
        VALUES (?, ?, ?, ?, ?)
        ''', (sender_id, receiver_id, serialize_character(character), receiver_username, receiver_first_name))
        conn.commit()

    keyboard = InlineKeyboardMarkup(
        [
            [InlineKeyboardButton("✅ Confirm Gift", callback_data="confirm_gift")],
            [InlineKeyboardButton("❌ Cancel Gift", callback_data="cancel_gift")]
        ]
    )
    mention_text = f"<b><a href='https://t.me/{receiver_username}'>{receiver_first_name}</a></b>"
    caption = (f"Do you really want to gift this character\n{character['name']}? \n<b>Information As Follows:</b>\n\n"
               f"Rarity: {character['rarity']}\nAnime: {character['anime']}\nId: {character['id']}")

    await message.reply_photo(
        photo=character['img_url'],
        caption=caption,
        reply_markup=keyboard,
        parse_mode='HTML'
    )

async def confirm_callback(update: Update, context: CallbackContext) -> None:
    callback_query = update.callback_query
    sender_id = callback_query.from_user.id

    if sender_id in click_cache:
        await callback_query.answer("Don't Spam Buddy.", show_alert=True)
        return

    click_cache[sender_id] = time.time()

    async with gift_lock:
        cursor.execute('''
        SELECT receiver_id, character, receiver_username, receiver_first_name FROM pending_gifts WHERE sender_id=?
        ''', (sender_id,))
        row = cursor.fetchone()

        if not row:
            await callback_query.answer("This is not for you!", show_alert=True)
            return

        receiver_id, character_str, receiver_username, receiver_first_name = row
        character = deserialize_character(character_str)

    sender = await user_collection.find_one({'id': sender_id})
    receiver = await user_collection.find_one({'id': receiver_id})

    sender_characters = sender.get('characters', [])
    if character not in sender_characters:
        await callback_query.answer("You no longer have this character!", show_alert=True)
        return

    sender_characters.remove(character)
    await user_collection.update_one({'id': sender_id}, {'$set': {'characters': sender_characters}})

    if receiver:
        receiver_characters = receiver.get('characters', [])
       
        receiver_characters.append(character)
        await user_collection.update_one({'id': receiver_id}, {'$set': {'characters': receiver_characters}})
    else:
        new_receiver = {
            'id': receiver_id,
            'username': receiver_username,
            'first_name': receiver_first_name,
            'characters': [character]
        }
        await user_collection.insert_one(new_receiver)

    async with gift_lock:
        cursor.execute('''
        DELETE FROM pending_gifts WHERE sender_id=? AND receiver_id=?
        ''', (sender_id, receiver_id))
        conn.commit()

    mention_text = f"<b><a href='tg://user?id={receiver_id}'>{receiver_first_name}</a></b>"
    text = f"Gift successfully sent to {mention_text} 🎁!"
    await callback_query.edit_message_caption(
        caption=text,
        parse_mode='HTML'
    )

async def cancel_callback(update: Update, context: CallbackContext) -> None:
    callback_query = update.callback_query
    sender_id = callback_query.from_user.id

    if sender_id in click_cache:
        await callback_query.answer("Don't Spam Buddy", show_alert=True)
        return

    click_cache[sender_id] = time.time()

    async with gift_lock:
        cursor.execute('''
        SELECT receiver_id FROM pending_gifts WHERE sender_id=?
        ''', (sender_id,))
        row = cursor.fetchone()

        if not row:
            await callback_query.answer("This is not for you!", show_alert=True)
            return

        receiver_id = row[0]

    async with gift_lock:
        cursor.execute('''
        DELETE FROM pending_gifts WHERE sender_id=? AND receiver_id=?
        ''', (sender_id, receiver_id))
        conn.commit()

    await callback_query.edit_message_caption(caption="Gift has been canceled ❌")

application.add_handler(CommandHandler("gift", gift, block=False))
confirm_handler = CallbackQueryHandler(confirm_callback, pattern='^confirm_gift$', block=False)
cancel_handler = CallbackQueryHandler(cancel_callback, pattern='^cancel_gift$', block=False)
application.add_handler(confirm_handler)
application.add_handler(cancel_handler)
    
