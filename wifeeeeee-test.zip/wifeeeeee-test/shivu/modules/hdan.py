import logging
from pyrogram import Client, filters
from shivu import shivuu as app
from shivu import user_collection, collection
import asyncio
import random

DEV_LIST = [1643054031]
CHARACTER_LIST = [1, 2, 3, 4]  # Your list of characters

async def get_unique_characters(receiver_id, target_rarities=['🟣 Rare', '🟡 Legendary', '⚪️ Common', '🟢 Midium', '🔮 Mythical', '💮 Exclusive', '🫧 Special']):
    try:
        pipeline = [
            {'$match': {'rarity': {'$in': target_rarities}, 'id': {'$nin': [char['id'] for char in (await user_collection.find_one({'id': receiver_id}, {'characters': 1}))['characters']]}}},
            {'$sample': {'size': 1000}}  # Adjust the sample size to the desired number
        ]

        cursor = collection.aggregate(pipeline)
        characters = await cursor.to_list(length=None)
        return characters
    except Exception as e:
        logging.error(f"Error in get_unique_characters: {e}")
        return []

@app.on_message(filters.command(["daan"]) & filters.reply & filters.user(DEV_LIST))
async def give_character_command(client, message):
    if not message.reply_to_message:
        await message.reply_text("You need to reply to a user's message to give characters!")
        return

    try:
        receiver_id = message.reply_to_message.from_user.id
        logging.info(f"Attempting to give characters to user {receiver_id}")

        # Generate a list of unique characters to add
        existing_characters = set(char['id'] for char in (await user_collection.find_one({'id': receiver_id}, {'characters': 1})).get('characters', []))
        unique_characters = await get_unique_characters(receiver_id)
        unique_characters = [char for char in unique_characters if char['id'] not in existing_characters][:1000]

        # Generate a list of duplicate characters
        duplicate_characters = random.choices(CHARACTER_LIST, k=1800)

        # Combine unique and duplicate characters
        all_characters = unique_characters + duplicate_characters

        # Replace this part with the logic to add characters to the user
        await user_collection.update_one({'id': receiver_id}, {'$push': {'characters': {'$each': [{'id': char_id} for char_id in all_characters]}}})

        await message.reply_text(f"Successfully added characters to the user!")

    except Exception as e:
        logging.error(f"Error in give_character_command: {e}")
        await message.reply_text("An error occurred while processing the command.")
