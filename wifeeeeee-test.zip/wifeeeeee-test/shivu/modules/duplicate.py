import re
import time
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import CallbackContext, CommandHandler, CallbackQueryHandler
from shivu import user_collection, application

current_page = 0
duplicates = []
processing_message = None

async def find_duplicate_characters(user_id):
    cursor = user_collection.aggregate([
        {"$match": {"id": user_id}},  # Match the specific user
        {"$unwind": "$characters"},
        {"$group": {
            "_id": {"name": "$characters.name", "rarity": "$characters.rarity", "anime": "$characters.anime", "id": "$characters.id"},
            "count": {"$sum": 1}
        }},
        {"$match": {"count": {"$gt": 1}}}
    ])
    
    duplicates = []
    async for data in cursor:
        name = data['_id']['name']
        rarity = data['_id']['rarity']
        anime = data['_id']['anime']
        char_id = data['_id']['id']
        count = data['count']
        duplicates.append({"name": name, "rarity": rarity, "anime": anime, "id": char_id, "count": count})
    
    return duplicates


async def find_duplicates(update: Update, context: CallbackContext) -> None:
    global current_page, duplicates, processing_message
    try:
        user_id = update.effective_user.id
        duplicates = await find_duplicate_characters(user_id)
        
        if not duplicates:
            await update.message.reply_text("<b>ʏᴏᴜ ᴅᴏɴ'ᴛ ᴏᴡɴ ᴀɴʏ ᴅᴜᴘʟɪᴄᴀᴛᴇ ᴄʜᴀʀᴀᴄᴛᴇʀs</b>", parse_mode='HTML')
            return
        
        current_page = 0
        processing_message = await update.message.reply_text("<b>ᴄᴏᴜɴᴛɪɴɢ...</b>", parse_mode='HTML')
        
        await send_pagination(update, user_id)

    except Exception as e:
        print(e)
        await update.message.reply_text('<b>sᴏᴍᴛʜɪɴɢ ᴡᴇɴᴛ ᴡʀᴏɴɢ ʀᴇᴘᴏʀᴛ ᴀᴛ @The_Catch_Squad</b>', parse_mode='HTML')

async def send_pagination(update, user_id):
    global current_page, processing_message, duplicates
    items_per_page = 5
    total_pages = (len(duplicates) + items_per_page - 1) // items_per_page

    current_duplicates = duplicates[current_page * items_per_page: (current_page + 1) * items_per_page]
    message = f"<b>ʜᴇʀᴇ ɪs ʏᴏᴜʀ ᴅᴜᴘʟɪᴄᴀᴛᴇ ᴄʜᴀʀᴀᴄᴛᴇʀs ʟɪsᴛ:</b>\n\n"
    
    for i, duplicate in enumerate(current_duplicates, start=current_page * items_per_page + 1):
        message += (f"<b>{i}. ɴᴀᴍᴇ:</b> {duplicate['name']}\n"
                    f"<b>ʀᴀʀɪᴛʏ:</b> {duplicate['rarity']}\n"
                    f"<b>ɪᴅ:</b> {duplicate['id']}\n"
                    f"<b>ᴀɴɪᴍᴇ:</b> {duplicate['anime']}\n"
                    f"<b>ᴄᴏᴜɴᴛ:</b> {duplicate['count']}\n\n")
    
    message += f"\nᴘᴀɢᴇ {current_page + 1}/{total_pages}"

    reply_markup = None
    if total_pages > 1:
        buttons = []
        if current_page > 0:
            buttons.append(InlineKeyboardButton("⬅️ ᴘʀᴇᴠɪᴏᴜs", callback_data=f"duplicate_prev_{user_id}"))
        if current_page < total_pages - 1:
            buttons.append(InlineKeyboardButton("ɴᴇxᴛ ➡️", callback_data=f"duplicate_next_{user_id}"))
        reply_markup = InlineKeyboardMarkup([buttons])

    await processing_message.edit_text(message, reply_markup=reply_markup, parse_mode='HTML', disable_web_page_preview=True)

async def character_callback(update: Update, context: CallbackContext) -> None:
    global current_page
    query = update.callback_query
    data = query.data
    user_id = int(data.split("_")[2])
    
    if "duplicate_prev_" in data and current_page > 0:
        if query.from_user.id != user_id:
            await query.answer("Please don't stalk.", show_alert=True)
            return    
        current_page -= 1
        await send_pagination(query, user_id)
    elif "duplicate_next_" in data and (current_page + 1) * 5 < len(duplicates):
        if query.from_user.id != user_id:
            await query.answer("Please don't stalk.", show_alert=True)
            return    
        current_page += 1
        await send_pagination(query, user_id)

duplicate_callback_handler = CallbackQueryHandler(character_callback, pattern=r'^duplicate_prev_\d+$|^duplicate_next_\d+$', block=False)
application.add_handler(CommandHandler("wduplicate", find_duplicates, block=False))

application.add_handler(duplicate_callback_handler)
