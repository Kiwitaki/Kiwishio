from telegram import Update
from telegram.ext import ContextTypes,CallbackContext
from shivu import DEV_LIST
from functools import wraps

from shivu import banned_users
from typing import Optional, Tuple


async def is_user_banned(user_id: int) -> Tuple[bool, Optional[str]]:
    try:
        user = await banned_users.find_one({'user_id': user_id})
        if user:
            return True, user.get('reason', 'No reason provided.')
        return False, None
    except Exception as e:
        print(f"Error checking banned user: {e}")
        raise

def uban(func):
    async def decorator(update: Update, context: ContextTypes.DEFAULT_TYPE, *args, **kwargs):
        user_id = update.effective_user.id
        is_banned, banned_reason = await is_user_banned(user_id)  # Check if the user is banned

        if is_banned:
            await update.message.reply_text(f"You are banned from using this bot.\nReason: {banned_reason}")
            return None
        else:
            return await func(update, context, *args, **kwargs)
    return decorator
