from datetime import datetime
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import CallbackContext, CommandHandler
from shivu.modules.database.cd_db import add_cd, get_cd_token, remove_cd_token
from shivu import application, DEV_LIST

async def add_cd_tokens(update: Update, context: CallbackContext) -> None:
    user_id = update.effective_user.id
    if user_id not in DEV_LIST:
        return 
    try:
        token_amount = int(context.args[0])

        if update.message.reply_to_message:
            target_user_id = update.message.reply_to_message.from_user.id
        else:
            try:
                target_user_id = int(context.args[1])
            except (IndexError, ValueError):
                target_user_id = update.message.from_user.id
        
        await add_cd(target_user_id, token_amount)
        await update.message.reply_text(f"Added {token_amount} Dollers to user {target_user_id}.")
    except (IndexError, ValueError):
        await update.message.reply_text("Usage: /addc <amount> [user_id]")

add_cd_handler = CommandHandler('addc', add_cd_tokens, block=False)
application.add_handler(add_cd_handler)
