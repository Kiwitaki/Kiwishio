from datetime import datetime
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import CallbackContext, CommandHandler
from shivu.modules.database.cd_db import add_cd, get_cd_token, remove_cd_token
from shivu import user_collection as collection, application

support = [
    [
        InlineKeyboardButton("Support ↗️", url="https://t.me/Catch_Your_WH_Group")
    ]
]

async def send(update: Update, context: CallbackContext) -> None:
    sender_id = update.effective_user.id
    reply = update.message.reply_to_message

    if not reply:
        await update.message.reply_text("⚠️ *You must reply to a user's message to send Dollers.*", parse_mode='Markdown')
        return

    receiver_id = reply.from_user.id

    if reply.from_user.is_bot:
        await update.message.reply_text("🤖 *You can't send catch Dollers to a bot!*", parse_mode='Markdown')
        return

    if not context.args:
        await update.message.reply_text("💰 *Please specify an amount of Dollers to send.*", parse_mode='Markdown')
        return
    
    if sender_id == receiver_id:
        await update.message.reply_text("🚫 *You can't send Dollers to yourself.*", parse_mode='Markdown')
        return

    try:
        amount = int(context.args[0])
    except ValueError:
        await update.message.reply_text("❗ *Please specify a valid amount of Dollers to send.*", parse_mode='Markdown')
        return

    if amount <= 0:
        await update.message.reply_text("🔢 *Please specify a positive amount of Dollers to send.*", parse_mode='Markdown')
        return

    sender_data = await collection.find_one({"id": sender_id})
    receiver_data = await collection.find_one({"id": receiver_id})

    if sender_data is None or receiver_data is None:
        await update.message.reply_text("⚠️ *Both sender and receiver must have an account.*", parse_mode='Markdown')
        return

    if await get_cd_token(sender_id) < amount:
        await update.message.reply_text("💸 *You don't have enough catch dollars.*", parse_mode='Markdown')
        return

    try:
        await remove_cd_token(sender_id, amount)
        await add_cd(receiver_id, amount)
        receiver_name = f"@{reply.from_user.username}" if reply.from_user.username else reply.from_user.first_name
        await update.message.reply_text(f"🎉 *Successfully gifted {amount} Waifu Dollers to {receiver_name}!*", parse_mode='Markdown')
    except Exception as e:
        await update.message.reply_text(f"❌ *An error occurred: {str(e)}*", parse_mode='Markdown')

send_handler = CommandHandler('wsend', send, block=False)
application.add_handler(send_handler)
