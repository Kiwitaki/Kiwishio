from shivu.modules.database.cd_db import get_cd_token
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import CallbackContext, CallbackQueryHandler, CommandHandler
from shivu import user_collection, application 

support = [
    [
        InlineKeyboardButton("Support ↗️", url="https://t.me/Catch_Your_WH_Group")
    ]
]

async def pocket(update: Update, context: CallbackContext):
    user_id = update.effective_user.id

    try:
        user = await user_collection.find_one({"id": user_id})
        if not user:
            return await update.message.reply_text("Secure Some Characters and get some coins first.")
        
        username = update.effective_user.username
        cd = await get_cd_token(user_id)  # Assuming `get_xp_token_info` was intended to be `get_cd_token`
        
        pocket_info = f"""<b>{update.effective_user.first_name}, Here is Your Pocket Balance:</b>

▰▰▰▰▰▰▰▰▰▰▰▰▰
<b>❅ Pocket Of @{username}</b>

💲 Currency:
<b>❅ Waifu Dollers ➳ </b> {cd}

▰▰▰▰▰▰▰▰▰▰▰▰▰
"""
        markup = InlineKeyboardMarkup(support)
        await update.message.reply_text(pocket_info, parse_mode='HTML', reply_markup=markup)
    
    except Exception as e:
        await update.message.reply_text("Something went wrong, please report to @Catch_Your_WH_Group.")
        print(e)


lol_handler = CommandHandler('wpocket', pocket, block=False)
application.add_handler(lol_handler)
