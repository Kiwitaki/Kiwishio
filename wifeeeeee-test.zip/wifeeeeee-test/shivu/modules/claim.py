import asyncio
from pyrogram import filters, Client, types as t
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from shivu import shivuu as bot
from shivu import user_collection, collection
from datetime import datetime, timedelta
from pyrogram.errors.exceptions.bad_request_400 import UserNotParticipant

DEVS = (1643054031, 6312693124, 8015760732, 6384296585)  # Developer user IDs
SUPPORT_CHAT_ID = -1002134049876  # Your group's chat ID

keyboard = InlineKeyboardMarkup([
    [InlineKeyboardButton("Join Chat To Use Me", url="https://t.me/Catch_Your_WH_Group")],
    [InlineKeyboardButton("Join Chat To Use Me", url="https://t.me/CATCH_YOUR_WH_UPDATES")]
])

async def claim_toggle(claim_state):
    try:
        await collection.update_one({}, {"$set": {"claim": claim_state}}, upsert=True)
    except Exception as e:
        print(f"Error in claim_toggle: {e}")

async def get_claim_state():
    try:
        doc = await collection.find_one({})
        return doc.get("claim", "False")
    except Exception as e:
        print(f"Error in get_claim_state: {e}")
        return "False"

async def add_claim_user(user_id):
    try:
        today_date = datetime.utcnow().strftime('%Y-%m-%d')
        await user_collection.update_one({"id": user_id}, {"$set": {"last_claim_date": today_date}}, upsert=True)
    except Exception as e:
        print(f"Error in add_claim_user: {e}")

async def get_last_claim_date(user_id):
    try:
        doc = await user_collection.find_one({"id": user_id}, {"last_claim_date": 1})
        return doc.get("last_claim_date", None)
    except Exception as e:
        print(f"Error in get_last_claim_date: {e}")
        return None

async def get_unique_characters(receiver_id, target_rarities=['🟡 Legendary']):
    try:
        pipeline = [
            {'$match': {'rarity': {'$in': target_rarities}, 'id': {'$nin': [char['id'] for char in (await user_collection.find_one({'id': receiver_id}, {'characters': 1}))['characters']]}}},
            {'$sample': {'size': 1}}
        ]

        cursor = collection.aggregate(pipeline)
        characters = await cursor.to_list(length=None)
        return characters
    except Exception as e:
        print(f"Error in get_unique_characters: {e}")
        return []

@bot.on_message(filters.command(["startclaim"]) & filters.user(DEVS))
async def start_claim(message: t.Message):
    await claim_toggle("True")
    await message.reply_text("Claiming feature enabled!")

@bot.on_message(filters.command(["stopclaim"]) & filters.user(DEVS))
async def stop_claim(message: t.Message):
    await claim_toggle("False")
    await message.reply_text("Claiming feature disabled!")

@bot.on_message(filters.command(["claim"]))
async def claim(_, message: t.Message):
    chat_id = message.chat.id
    user_id = message.from_user.id
    mention = message.from_user.mention

    try:
        member = await bot.get_chat_member(-1002134049876, user_id)
        members = await bot.get_chat_member(-1001746346532, user_id)
        if member and members:
            pass
    except UserNotParticipant:
        await message.reply_text("You need to join the chat to use this feature.", reply_markup=keyboard)
        return 

    if chat_id != SUPPORT_CHAT_ID:
        return await message.reply_text(f"Command can only be used in the support chat: @Catch_Your_WH_Group")

    claim_state = await get_claim_state()
    if claim_state == "False":
        return await message.reply_text("Claiming feature is currently disabled.")

    last_claim_date = await get_last_claim_date(user_id)
    today_date = datetime.utcnow().strftime('%Y-%m-%d')

    if last_claim_date == today_date:
        return await message.reply_text("You've already claimed your daily reward today. Come back tomorrow!", quote=True)

    await add_claim_user(user_id)

    unique_characters = await get_unique_characters(user_id)
    if unique_characters:
        try:
            await user_collection.update_one({'id': user_id}, {'$push': {'characters': {'$each': unique_characters}}})
            for character in unique_characters:
                caption = (f"**Congratulations** {mention}!\n\n"
                           f"**Your Prize is:**\n"
                           f"**✨ Name:** {character['name']}\n"
                           f"**💓 Anime:** {character['anime']}\n\n"
                           f"**Come back tomorrow 🍀**")
                await message.reply_photo(photo=character['img_url'], caption=caption)
        except Exception as e:
            print(f"Error in claim: {e}")
    else:
        await message.reply_text(f"Sorry {mention}, no unique characters were available for your claim today.")
        
