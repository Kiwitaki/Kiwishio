from shivu import collection
from shivu import user_collection, application
from telegram import (
    Update, InlineKeyboardButton, InlineKeyboardMarkup, InlineQueryResultPhoto,
    InputTextMessageContent, InputMediaPhoto, InlineQueryResultArticle
)
from telegram.ext import (
    Updater, CommandHandler, CallbackContext, MessageHandler, filters,
    InlineQueryHandler, CallbackQueryHandler, ChosenInlineResultHandler
)
import logging
from cachetools import TTLCache

rarity_cache = TTLCache(maxsize=1000, ttl=300)

async def get_rarity_summary(user_id):
    if user_id in rarity_cache:
        return rarity_cache[user_id]

    user = await user_collection.find_one({'id': user_id})
    if not user:
        return {"Rarities": {}}  # Return empty if user not found

    all_characters = await collection.find({}).to_list(length=None)

    unique_user_characters = {character['id']: character for character in user.get('characters', [])}.values()

    user_rarity_count = {}
    for character in unique_user_characters:
        rarity = character.get('rarity')
        if rarity:
            user_rarity_count[rarity] = user_rarity_count.get(rarity, 0) + 1

    total_rarity_count = {}
    for character in all_characters:
        rarity = character.get('rarity')
        if rarity:
            total_rarity_count[rarity] = total_rarity_count.get(rarity, 0) + 1

    # Sorting rarities dynamically found in the collection and user's characters alphabetically
    all_rarities = sorted(set(total_rarity_count.keys()) | set(user_rarity_count.keys()))

    rarity_summary = {rarity: f"{user_rarity_count.get(rarity, 0)}/{total_rarity_count.get(rarity, 0)}" for rarity in all_rarities}

    summary = {
        "Rarities": {rarity: rarity_summary[rarity] for rarity in all_rarities}
    }

    rarity_cache[user_id] = summary
    return summary


async def rarity_cmd(update: Update, context: CallbackContext):
    user_id = update.effective_user.id

    try:
        rarity_summary = await get_rarity_summary(user_id)
        
        summary_text = "<b>✨ Your Character Collection by Rarity ✨</b>\n\n"
        summary_text += "🔹 <b>Rarities:</b>\n"

        for rarity, count in rarity_summary["Rarities"].items():
            parts = rarity.split(' ', 1)
            if len(parts) == 2:
                summary_text += f"• <b>{parts[0]}</b> {parts[1]}: <i>{count}</i>\n"
            else:
                summary_text += f"• <b>{rarity}</b>: <i>{count}</i>\n"

        summary_text += "\n✨ <i>Keep collecting to complete your harem!</i> ✨"
        await update.message.reply_text(summary_text, parse_mode='HTML')

    except Exception as e:
        logger.error(f"Error in rarity_cmd: {e}")
        await update.message.reply_text('An error occurred while generating the rarity summary.')

style = {
    "a": "ᴀ", "b": "ʙ", "c": "ᴄ", "d": "ᴅ", "e": "ᴇ", "f": "ғ", "g": "ɢ", "h": "ʜ",
    "i": "ɪ", "j": "J", "k": "ᴋ", "l": "ʟ", "m": "ᴍ", "n": "ɴ", "o": "ᴏ", "p": "ᴘ",
    "q": "ǫ", "r": "ʀ", "s": "s", "t": "ᴛ", "u": "ᴜ", "v": "ᴠ", "w": "ᴡ", "x": "x",
    "y": "ʏ", "z": "ᴢ"
}

async def get_name(letter: str):
    anime_list = await collection.find({"anime": {"$regex": f"^{letter}", "$options": "i"}}).to_list(length=None)
    anime_names = list({anime['anime'] for anime in anime_list})
    return anime_names

async def animelist_cmd(update: Update, context: CallbackContext) -> None:
    page = 0
    user_id = update.effective_user.id
    buttons = generate_letter_buttons(page, user_id)
    keyboard = InlineKeyboardMarkup(buttons)
    await update.message.reply_text("<b>🔍 sᴇʟᴇᴄᴛ ᴀɴ sᴛᴀʀᴛɪɴɢ ʟᴇᴛᴛᴇʀ ᴏғ ᴀɴɪᴍᴇ ɴᴀᴍᴇ:</b>", reply_markup=keyboard, parse_mode='HTML')

def generate_letter_buttons(page: int, user_id: int):
    letters = [chr(i) for i in range(65, 91)]
    styled_letters = [style[letter.lower()] for letter in letters]
    start_index = page * 12
    current_letters = styled_letters[start_index:start_index + 12]

    buttons = [[InlineKeyboardButton(current_letters[i], callback_data=f'letter:{letters[start_index + i]}:{page}:{user_id}')
                for i in range(row, min(row + 4, len(current_letters)))] 
               for row in range(0, len(current_letters), 4)]

    total_pages = (len(styled_letters) - 1) // 12

    if page == 0:
        buttons.append([InlineKeyboardButton("ɴᴇxᴛ ➡️", callback_data=f'letter_page:{page+1}:{user_id}')])
    elif page == total_pages:
        buttons.append([InlineKeyboardButton("⬅️ ᴘʀᴇᴠɪᴏᴜs", callback_data=f'letter_page:{page-1}:{user_id}')])
    else:
        buttons.append([
            InlineKeyboardButton("⬅️ ᴘʀᴇᴠɪᴏᴜs", callback_data=f'letter_page:{page-1}:{user_id}'),
            InlineKeyboardButton("ɴᴇxᴛ ➡️", callback_data=f'letter_page:{page+1}:{user_id}')
        ])

    return buttons

def generate_anime_buttons(anime_list, letter: str, page: int, user_id: int):
    start_index = page * 6
    current_animes = anime_list[start_index:start_index + 6]

    buttons = [[InlineKeyboardButton(anime, callback_data=f'anime:{anime.replace(" ", "_")}:{letter}:{page}:{user_id}')] 
               for anime in current_animes]

    total_pages = (len(anime_list) - 1) // 6

    if page == 0:
        buttons.append([InlineKeyboardButton("ɴᴇxᴛ ➡️", callback_data=f'anime_page:{letter}:{page+1}:{user_id}')])
    elif page == total_pages:
        buttons.append([InlineKeyboardButton("⬅️ ᴘʀᴇᴠɪᴏᴜs", callback_data=f'anime_page:{letter}:{page-1}:{user_id}')])
    else:
        buttons.append([
            InlineKeyboardButton("⬅️ ᴘʀᴇᴠɪᴏᴜs", callback_data=f'anime_page:{letter}:{page-1}:{user_id}'),
            InlineKeyboardButton("ɴᴇxᴛ ➡️", callback_data=f'anime_page:{letter}:{page+1}:{user_id}')
        ])

    return buttons

async def letter_callback(update: Update, context: CallbackContext) -> None:
    query = update.callback_query
    data = query.data.split(':')
    user_id = int(data[-1])

    if query.from_user.id != user_id:
        await query.answer("Please don't stalk.", show_alert=True)
        return

    if data[0] == 'letter':
        letter = data[1]
        anime_list = await get_name(letter)

        if anime_list:
            buttons = generate_anime_buttons(anime_list, letter, 0, user_id)
            keyboard = InlineKeyboardMarkup(buttons)
            await query.message.edit_text(f"<b>ʜᴇʀᴇ ɪs ʟɪsᴛ ᴏғ ᴀʟʟ ᴀɴɪᴍᴇs ᴡɪᴛʜ ʟᴇᴛᴛᴇʀ {letter}:</b>", reply_markup=keyboard, parse_mode='HTML')
        else:
            await query.message.edit_text(f"<b>ɴᴏ ᴀɴɪᴍᴇ ғᴏᴜɴᴅ ᴡɪᴛʜ ʟᴇᴛᴛᴇʀ {letter}.</b>", parse_mode='HTML')

    elif data[0] == 'letter_page':
        page = int(data[1])
        buttons = generate_letter_buttons(page, user_id)
        keyboard = InlineKeyboardMarkup(buttons)
        await query.message.edit_text("<b>🔍 sᴇʟᴇᴄᴛ ᴀɴ sᴛᴀʀᴛɪɴɢ ʟᴇᴛᴛᴇʀ ᴏғ ᴀɴɪᴍᴇ ɴᴀᴍᴇ:</b>", reply_markup=keyboard, parse_mode='HTML')

async def anime_callback(update: Update, context: CallbackContext) -> None:
    query = update.callback_query
    data = query.data.split(':')
    user_id = int(data[-1])

    if query.from_user.id != user_id:
        await query.answer("Please don't stalk.", show_alert=True)
        return

    if data[0] == 'anime':
        anime_name = data[1].replace("_", " ")
        await query.message.edit_text(f'<b>ʏᴏᴜ sᴇʟᴇᴄᴛᴇᴅ "{anime_name}" ᴘʟᴇᴀsᴇ ɢᴏ ɪɴʟɪɴᴇ ᴍᴏᴅᴇ ᴛᴏ sᴇᴇ ᴀʟʟ ᴄʜᴀʀᴀᴄᴛᴇʀs ᴏғ ʏᴏᴜʀ ғᴀᴠᴏᴜʀɪᴛᴇ ᴀɴɪᴍᴇ</b>', parse_mode='HTML', reply_markup=InlineKeyboardMarkup(
            [[InlineKeyboardButton(f"𝐆𝐨 𝐈𝐧𝐥𝐢𝐧𝐞 𝐌𝐨𝐝𝐞 🔍", switch_inline_query_current_chat=f"{anime_name}")]]
        ))

    elif data[0] == 'anime_page':
        letter = data[1]
        page = int(data[2])
        anime_list = await get_name(letter)

        if anime_list:
            buttons = generate_anime_buttons(anime_list, letter, page, user_id)
            keyboard = InlineKeyboardMarkup(buttons)
            await query.message.edit_text(f"<b>ʜᴇʀᴇ ɪs ʟɪsᴛ ᴏғ ᴀʟʟ ᴀɴɪᴍᴇs ᴡɪᴛʜ ʟᴇᴛᴛᴇʀ {letter}:</b>", reply_markup=keyboard, parse_mode='HTML')
        else:
            await query.message.edit_text(f"<b>ɴᴏ ᴀɴɪᴍᴇ ғᴏᴜɴᴅ ᴡɪᴛʜ ʟᴇᴛᴛᴇʀ {letter}.</b>", parse_mode='HTML')



application.add_handler(CommandHandler("wrarity", rarity_cmd, block=False))
application.add_handler(CommandHandler("wanimelist", animelist_cmd, block=False))

application.add_handler(CallbackQueryHandler(letter_callback, pattern=r'letter', block=False))
application.add_handler(CallbackQueryHandler(anime_callback, pattern=r'anime', block=False))                        
