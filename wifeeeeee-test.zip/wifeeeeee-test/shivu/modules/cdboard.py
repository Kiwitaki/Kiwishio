from shivu import user_collection, application, PHOTO_URL
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import CommandHandler, CallbackContext, CallbackQueryHandler
import logging
import random
from telegram.constants import ParseMode

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

async def mention_user(user_id):
    user = await user_collection.find_one({'id': user_id}, {'username': 1, 'first_name': 1})
    if user:
        username = user.get('username')
        first_name = user.get('first_name', 'Unknown')[:15] + '...' if len(user.get('first_name', 'Unknown')) > 10 else user.get('first_name', 'Unknown')
        return f'<a href="https://t.me/{username}">{first_name}</a>'
    return "Unknown"

async def get_top_currency_users():
    try:
        cursor = user_collection.aggregate([
            {"$match": {"id": {"$exists": True}, "cd": {"$gt": 0}}},
            {"$project": {"id": 1, "first_name": 1, "cd": 1}},
            {"$sort": {"cd": -1}},
            {"$limit": 10}
        ])
        top_users = await cursor.to_list(length=10)
        logger.info(f"Top users in coins: {top_users}")

        top_users_list = [
            {
                "id": user.get("id"),
                "first_name": user.get("first_name", "Unknown"),
                "cd": user.get("cd", 0)
            }
            for user in top_users if user.get("id") is not None
        ]
        return top_users_list
    except Exception as e:
        logger.error(f"Error in get_top_currency_users: {e}")
        return []

async def display_top_currency(update: Update, context: CallbackContext) -> None:
    try:
        top_users = await get_top_currency_users()
        leaderboard_message = "<b>🏆 Top 10 Wealthiest Users</b>\n\n"

        for i, user in enumerate(top_users, start=1):
            user_id = user['id']
            user_mention = await mention_user(user_id)
            user_currency = user['cd']

            leaderboard_message += f'{i}. {user_mention} ➾ <b>{user_currency}</b>\n'

        photo_url = random.choice(PHOTO_URL)
        keyboard = InlineKeyboardMarkup(
            [[InlineKeyboardButton("🚮 Delete", callback_data="delete_leaderboard")]]
        )
        await update.message.reply_photo(photo=photo_url, caption=leaderboard_message, reply_markup=keyboard, parse_mode=ParseMode.HTML)
    except Exception as e:
        logger.error(f"Error in display_top_currency: {e}")
        await update.message.reply_text("⚠️ An error occurred while retrieving the leaderboard.")

async def handle_delete_callback(update: Update, context: CallbackContext):
    callback_query = update.callback_query
    if callback_query.data == "delete_leaderboard":
        await callback_query.message.delete()


top_currency_handler = CommandHandler('topc', display_top_currency, block=False)
application.add_handler(top_currency_handler)

application.add_handler(CallbackQueryHandler(handle_delete_callback, pattern='^delete_leaderboard$'))
