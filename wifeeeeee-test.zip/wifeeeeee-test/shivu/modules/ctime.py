from pymongo import ReturnDocument
from telegram import Update
from telegram.ext import CommandHandler, CallbackContext
from shivu import application, OWNER_ID, user_totals_collection, DEV_LIST

async def change_time(update: Update, context: CallbackContext) -> None:
    user = update.effective_user
    chat = update.effective_chat

    try:
        member = await chat.get_member(user.id)
        if member.status not in ('administrator', 'creator'):
            await update.message.reply_text('You do not have permission to use this command.')
            return

        args = context.args
        if len(args) != 1:
            await update.message.reply_text('Incorrect format. Please use: /changetime NUMBER')
            return

        new_frequency = int(args[0])
        if new_frequency < 100:
            await update.message.reply_text('The message frequency must be greater than or equal to 100.')
            return

        if new_frequency > 10000:
            await update.message.reply_text('Thats too much buddy. Use below 10000')
            return

        chat_frequency = await user_totals_collection.find_one_and_update(
            {'chat_id': str(chat.id)},
            {'$set': {'message_frequency': new_frequency}},
            upsert=True,
            return_document=ReturnDocument.AFTER
        )

        await update.message.reply_text(f'Successfully changed character appearance frequency to every {new_frequency} messages.')
    except Exception as e:
        await update.message.reply_text('Failed to change character appearance frequency.')


async def change_time_sudo(update: Update, context: CallbackContext) -> None:
    sudo_user_ids = {1643054031,5443243540,6988555661,8015760732,6384296585}
    user = update.effective_user

    try:
        if user.id not in DEV_LIST:
            await update.message.reply_text('You do not have permission to use this command.')
            return

        args = context.args
        if len(args) != 1:
            await update.message.reply_text('Incorrect format. Please use: /changetime NUMBER')
            return

        new_frequency = int(args[0])
        if new_frequency < 1:
            await update.message.reply_text('The message frequency must be greater than or equal to 1.')
            return

        if new_frequency > 10000:
            await update.message.reply_text('Thats too much buddy. Use below 10000')
            return

        chat_frequency = await user_totals_collection.find_one_and_update(
            {'chat_id': str(update.effective_chat.id)},
            {'$set': {'message_frequency': new_frequency}},
            upsert=True,
            return_document=ReturnDocument.AFTER
        )

        await update.message.reply_text(f'Successfully changed character appearance frequency to every {new_frequency} messages.')
    except Exception as e:
        await update.message.reply_text('Failed to change character appearance frequency.')


async def change_rarity_sudo(update: Update, context: CallbackContext) -> None:
    sudo_user_ids = {1643054031, 6312693124,1643054031,5443243540,6988555661,8015760732,6384296585}
    user = update.effective_user

    
    rarity_mapping = {
        "🍬": "🍬  Galactic",
        "🪔": "🪔 Diwali edition",
        "❌": "None"
    }

    try:
        if user.id not in sudo_user_ids:
            await update.message.reply_text('You do not have permission to use this command.')
            return

        args = context.args
        if len(args) != 1:
            await update.message.reply_text('Incorrect format. Please use: /cr [emoji]. Example: /cr 🍬')
            return

        emoji_input = args[0]  # Extract the first argument (the emoji)

        if emoji_input not in rarity_mapping:
            await update.message.reply_text("Invalid emoji. Please use either 🍬, 🪔, or ❌ (None).")
            return

        new_rarity = rarity_mapping[emoji_input]

        await user_totals_collection.find_one_and_update(
            {'chat_id': str(update.effective_chat.id)},
            {'$set': {'rarity': new_rarity}},
            upsert=True,
            return_document=ReturnDocument.AFTER
        )

        await update.message.reply_text(f'Successfully changed character rarity to {new_rarity}.')
    except Exception as e:
        await update.message.reply_text(f'Failed to change character rarity. Error: {e}')
        

async def change_timee_sudo(update: Update, context: CallbackContext) -> None:
    sudo_user_ids = {6312693124, 6312693124,1643054031,5443243540,6988555661,8015760732,6384296585}
    user = update.effective_user

    try:
        if user.id not in sudo_user_ids:
            await update.message.reply_text('You do not have permission to use this command.')
            return

        args = context.args
        if len(args) != 1:
            await update.message.reply_text('Incorrect format. Please use: /changetime NUMBER')
            return

        new_frequency = int(args[0])
        if new_frequency < 1:
            await update.message.reply_text('The message frequency must be greater than or equal to 1.')
            return

        if new_frequency > 10000:
            await update.message.reply_text('Thats too much buddy. Use below 10000')
            return

        chat_frequency = await user_totals_collection.find_one_and_update(
            {'chat_id': str(update.effective_chat.id)},
            {'$set': {'spe_frequency': new_frequency}},
            upsert=True,
            return_document=ReturnDocument.AFTER
        )

        await update.message.reply_text(f'Successfully changed character appearance frequency to every {new_frequency} messages.')
    except Exception as e:
        await update.message.reply_text('Failed to change character appearance frequency.')


application.add_handler(CommandHandler("ctime", change_time_sudo, block=False))
application.add_handler(CommandHandler("changetime", change_time, block=False))
application.add_handler(CommandHandler("cr", change_rarity_sudo, block=False))
application.add_handler(CommandHandler("stime", change_timee_sudo, block=False))
