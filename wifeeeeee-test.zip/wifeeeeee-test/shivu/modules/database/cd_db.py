from shivu import user_collection
from datetime import datetime

async def add_cd(user_id, amount):
    result = await user_collection.update_one(
        {"id": user_id},
        {"$inc": {"cd": amount}},
        upsert=True
    )
    return result.modified_count


async def get_cd_token(user_id):
    user = await user_collection.find_one({"id": user_id})
    return user.get("cd", 0) if user else 0


async def remove_cd_token(user_id, amount):
    await user_collection.update_one(
        {"id": user_id, "cd": {"$gte": amount}},
        {"$inc": {"cd": -amount}}
    )
