from shivu import collection
from shivu import user_collection, application 
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import CallbackContext, CommandHandler
import re
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

async def check_character(character_id,user_id):
    character = await collection.find_one({'id': character_id})

    if character:        
        try:
            img_url = character['img_url']

            caption = f"""<b>[ Charcter Details ]</b>
• <b>Name:</b> {character['name']}
• <b>Anime:</b> {character['anime']}
• <b>Rarity:</b> {character['rarity']}
• <b>ID:</b> {character['id']}
"""

            return img_url, caption
        except Exception as e:
            logger.error(f"Error retrieving character details: {e}")
            raise
    else:
        raise ValueError("Character not found.")

async def character_cmd(update: Update, context: CallbackContext) -> None:
    user_id = update.effective_user.id
    args = context.args
    if len(args) != 1:
        await update.message.reply_text('Incorrect format. Please use: /wchar <id>')
        return

    character_id = args[0]
    try:
        photo, caption = await check_character(character_id,user_id)
        await update.message.reply_photo(photo=photo, caption=caption, parse_mode='HTML')
    except ValueError as e:
        await update.message.reply_text(str(e))
    except Exception as e:
        logger.error(f"Error in character_cmd: {e}")
        await update.message.reply_text('An error occurred while retrieving the character.')

application.add_handler(CommandHandler(["w","wchar"], character_cmd))
