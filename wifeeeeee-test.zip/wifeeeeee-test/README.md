
<p align="center">
  <img src="https://telegra.ph/file/14d693b36bd6f1307704a.jpg"/>
</p>


## USER COMMANDS
- `/guess`
- `/fav`
- `/trade`
- `/gift`
- `/collection`
- `/topgroups`
- `/top`
- `/ctop`
- `/changetime`
  
## SUDO USER COMMANDS..
- `/upload`
- `/delete`
- `/update`

## OWNER COMMANDS
- `/ping`
- `/broadcast `
- `/stats`
- `/list`
- `/groups`


<p align="center">
<b>𝗗𝗘𝗣𝗟𝗢𝗬𝗠𝗘𝗡𝗧 𝗠𝗘𝗧𝗛𝗢𝗗𝗦</b>
</p>

<h3 align="center">
    ─「 ᴅᴇᴩʟᴏʏ ᴏɴ ʜᴇʀᴏᴋᴜ 」─
</h3>

<p align="center"><a href="https://dashboard.heroku.com/new?template=https://github.com/takiunkwondev/wifeeeeee"> <img src="https://img.shields.io/badge/Deploy%20On%20Heroku-black?style=for-the-badge&logo=heroku" width="220" height="38.45"/></a></p>
